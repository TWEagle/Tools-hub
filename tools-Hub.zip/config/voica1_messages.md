[[CERTMAIL]]
Beste,

In bijlage vind je de volgende devices:
{{devices}}

Het wachtwoord vind je in de gekende kanalen

Met vriendelijke groeten
Team DCBaaS
[[END]]

[[OTS]]
Beste

Hieronder vind je het wachtwoord voor de volgende devices:
{{devices}}

{{password}}

Met vriendelijke groeten
Team DCBaaS
[[END]]

[[WA]]
Beste

Hieronder vind je het wachtwoord voor de volgende devices:
{{devices}}

{{password}}

Geef je een duimpje omhoog als je het wachtwoord niet meer nodig hebt!
Dit voor de veiligheid!!!

Met vriendelijke groeten
Team DCBaaS
[[END]]

[[SIGNAL]]
Beste

Hieronder vind je het wachtwoord voor de volgende devices:
{{devices}}

{{password}}

Geef je een duimpje omhoog als je het wachtwoord niet meer nodig hebt!
Dit voor de veiligheid!!!

Met vriendelijke groeten
Team DCBaaS
[[END]]
